let _modPath;

exports.initialize = (modPath) => {
    _modPath = modPath;

    // Add new furniture the purchase view
    Database.items['coffeetable'] = {
        id: "coffeetable",
        name: "coffeetable",
        imagePath: `${modPath}images/coffee-table1-{orientation}.png`,
        price: 100,
        size: [2, 3],
        tier: 1,
        orientation: IsoDom.ORIENTATION_SW,
        images: {
            [IsoDom.ORIENTATION_NW]: {url: `${modPath}images/coffee-table1-1.png`, offset: {top: -140, left: -210}},
            [IsoDom.ORIENTATION_NE]: {url: `${modPath}images/coffee-table1-2.png`, offset: {top: -140, left: -330}},
            [IsoDom.ORIENTATION_SE]: {url: `${modPath}images/coffee-table1-3.png`, offset: {top: -140, left: -220}},
            [IsoDom.ORIENTATION_SW]: {url: `${modPath}images/coffee-table1-4.png`, offset: {top: -140, left: -330}},
        }
    }

    // Add new menu item
    Modding.setMenuItem({
        name: 'mymod',
        tooltip: "My Mod",
        tooltipPosition: 'top',
        faIcon: 'fa-cubes',
        badgeCount: 0,
    });

    // Define custom views
    exports.views = [
        {
            name: 'mymod',
            viewPath: _modPath + 'view.html',
            controller: function ($rootScope) {
                this.name = 'Jonas';
                this.giveMoney = (amount) => {
                    $rootScope.confirm('Are you sure?', `Are you sure you want ${numeral(amount).format(Configuration.CURRENCY_FORMAT)}?`, () => {
                        $rootScope.settings.balance += amount;
                    });
                }
            }
        }
    ]
};


exports.onLoadGame = settings => {
};
exports.onNewHour = settings => {
};
exports.onNewDay = settings => {
};

